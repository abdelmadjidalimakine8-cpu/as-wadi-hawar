# Site AS Wadi Hawar — première version

Cette première version comprend :
- une page d’accueil responsive en français ;
- une présentation du club et des catégories ;
- un formulaire public de pré-inscription ;
- l’envoi des demandes vers `public.registration_requests` dans Supabase ;
- un formulaire sans création de compte préalable ;
- une demande d’autorisation parentale pour les joueurs mineurs.

## 1. Configuration Supabase

1. Copiez `.env.example` et renommez la copie en `.env`.
2. Conservez l’URL du projet déjà indiquée.
3. Dans Supabase, ouvrez **Project Settings → API Keys**.
4. Copiez la **Publishable key** (elle commence par `sb_publishable_`) dans `VITE_SUPABASE_PUBLISHABLE_KEY`.
5. Ne mettez jamais une clé `service_role` ou `secret` dans ce projet frontend.

Le formulaire envoie uniquement les champs autorisés à l’insertion publique. Il ne lit pas les demandes après envoi.

## 2. Lancer le site sur un ordinateur

Installez Node.js 22 ou plus récent, puis ouvrez un terminal dans ce dossier :

```bash
npm install
npm run dev
```

Vite affichera une adresse locale à ouvrir dans le navigateur.

Pour vérifier la version de production :

```bash
npm run build
```

## 3. Publication

Le site est préparé pour être publié sur un hébergeur statique compatible avec Vite. Il faudra connecter le dossier à un dépôt Git puis à l’hébergeur choisi, et y ajouter les deux variables d’environnement du fichier `.env`.

## 4. Éléments à compléter avant ouverture au public

- Ajouter le logo officiel du club et les photos autorisées.
- Créer le tableau de bord privé du secrétariat pour examiner les demandes.
- Mettre en place l’envoi privé de photos et documents des joueurs ; aucun document sensible n’est téléversé par cette première version.
- Ajouter une protection anti-spam/CAPTCHA avant de rendre le formulaire public.
- Rédiger et publier une notice de confidentialité complète et la faire valider par les responsables du club.

## 5. Sécurité déjà prévue dans Supabase

La table `registration_requests` est protégée par RLS. Le rôle public `anon` peut seulement insérer les champs du formulaire ; il ne peut pas lire les demandes. Les responsables autorisés peuvent les consulter et les mettre à jour après connexion.
