import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export const supabaseReady = Boolean(url && publishableKey && !publishableKey.includes("COLLER_ICI"));

export const supabase = supabaseReady
  ? createClient(url, publishableKey)
  : null;