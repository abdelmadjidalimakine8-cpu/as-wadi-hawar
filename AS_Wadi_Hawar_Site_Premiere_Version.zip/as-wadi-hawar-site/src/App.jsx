import React, { useMemo, useState } from "react";
import { supabase, supabaseReady } from "./supabase";

const initialForm = {
  first_name: "",
  last_name: "",
  date_of_birth: "",
  nationality: "Tchadienne",
  city: "N’Djaména",
  phone: "",
  email: "",
  requested_category: "U17",
  preferred_position: "",
  previous_club: "",
  guardian_full_name: "",
  guardian_relationship: "",
  guardian_phone: "",
  guardian_email: "",
  parental_authorization_confirmed: false,
  privacy_consent: false,
};

function calculateAge(date) {
  if (!date) return null;
  const birth = new Date(`${date}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const beforeBirthday =
    today.getMonth() < birth.getMonth() ||
    (today.getMonth() === birth.getMonth() && today.getDate() < birth.getDate());
  if (beforeBirthday) age -= 1;
  return age;
}

function App() {
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const age = useMemo(() => calculateAge(form.date_of_birth), [form.date_of_birth]);
  const isMinor = age !== null && age < 18;

  const update = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
  };

  async function submit(event) {
    event.preventDefault();
    setFeedback(null);

    if (!supabaseReady || !supabase) {
      setFeedback({ type: "error", text: "Le formulaire n’est pas encore connecté. L’administrateur doit renseigner la clé publique Supabase dans le fichier .env." });
      return;
    }
    if (isMinor && (!form.guardian_full_name.trim() || !form.guardian_phone.trim() || !form.parental_authorization_confirmed)) {
      setFeedback({ type: "error", text: "Pour un joueur mineur, les coordonnées du parent ou tuteur et sa confirmation d’autorisation sont obligatoires." });
      return;
    }
    if (!form.privacy_consent) {
      setFeedback({ type: "error", text: "Veuillez confirmer que les informations fournies peuvent être utilisées pour traiter cette demande d’inscription." });
      return;
    }

    const payload = {
      ...form,
      email: form.email.trim() || null,
      preferred_position: form.preferred_position || null,
      previous_club: form.previous_club.trim() || null,
      guardian_full_name: isMinor ? form.guardian_full_name.trim() : null,
      guardian_relationship: isMinor ? (form.guardian_relationship || null) : null,
      guardian_phone: isMinor ? form.guardian_phone.trim() : null,
      guardian_email: isMinor ? (form.guardian_email.trim() || null) : null,
      parental_authorization_confirmed: isMinor ? form.parental_authorization_confirmed : false,
    };

    setSubmitting(true);
    const { error } = await supabase.from("registration_requests").insert(payload);
    setSubmitting(false);

    if (error) {
      setFeedback({ type: "error", text: "La demande n’a pas pu être envoyée. Vérifiez les champs puis réessayez. Si le problème continue, contactez le club." });
      return;
    }
    setForm(initialForm);
    setFeedback({ type: "success", text: "Votre demande de pré-inscription a bien été transmise à l’AS Wadi Hawar. Elle sera examinée par les responsables du club. Merci !" });
  }

  return (
    <>
      <header className="site-header">
        <a className="brand" href="#accueil" aria-label="AS Wadi Hawar - accueil">
          <div className="brand-mark">WH</div>
          <div><strong>AS WADI HAWAR</strong><span>Association Sportive de Football</span></div>
        </a>
        <nav>
          <a href="#club">Le club</a>
          <a href="#formation">Formation</a>
          <a href="#inscription">Inscription</a>
          <a href="#contact">Contact</a>
        </nav>
        <a className="header-cta" href="#inscription">Rejoindre le club</a>
      </header>

      <main>
        <section className="hero" id="accueil">
          <div className="hero-content">
            <p className="eyebrow">N’DJAMÉNA · TCHAD</p>
            <h1>Former aujourd’hui<br /><em>les talents de demain.</em></h1>
            <p className="hero-copy">Bienvenue sur le site officiel de l’Association Sportive de Football Wadi Hawar. Une équipe engagée dans la formation, l’éducation sportive et l’épanouissement des jeunes footballeurs.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#inscription">Faire une pré-inscription</a>
              <a className="button button-outline" href="#club">Découvrir le club</a>
            </div>
          </div>
          <div className="hero-panel">
            <div className="panel-top">AS WADI HAWAR</div>
            <div className="panel-ball">⚽</div>
            <div className="panel-bottom"><span>DISCIPLINE</span><span>FORMATION</span><span>ESPRIT D’ÉQUIPE</span></div>
          </div>
        </section>

        <section className="intro section" id="club">
          <div className="section-kicker">NOTRE ASSOCIATION</div>
          <h2>Une passion, une ambition,<br /><span>un avenir à construire.</span></h2>
          <p className="section-copy">L’AS Wadi Hawar accompagne les jeunes et les joueurs dans leur progression footballistique, avec un cadre fondé sur le respect, la discipline, le travail et la solidarité.</p>
          <div className="values">
            <article><b>01</b><h3>Formation</h3><p>Développer les qualités techniques, tactiques et humaines des joueurs.</p></article>
            <article><b>02</b><h3>Discipline</h3><p>Promouvoir le respect des règles, des éducateurs et des partenaires.</p></article>
            <article><b>03</b><h3>Collectif</h3><p>Faire grandir chaque joueur dans un esprit d’équipe et de solidarité.</p></article>
          </div>
        </section>

        <section className="formation section" id="formation">
          <div className="section-kicker">CENTRE DE FORMATION</div>
          <h2>Nos catégories</h2>
          <p className="section-copy">Les demandes de pré-inscription sont ouvertes pour les catégories suivantes. L’affectation définitive est confirmée par les responsables techniques du club.</p>
          <div className="category-grid">
            {["U12", "U15", "U17", "U18", "Seniors"].map((item) => <div className="category" key={item}><span>ASWH</span><strong>{item}</strong><small>Formation & compétition</small></div>)}
          </div>
        </section>

        <section className="registration section" id="inscription">
          <div className="registration-intro">
            <div className="section-kicker">REJOIGNEZ-NOUS</div>
            <h2>Pré-inscription<br /><span>joueur</span></h2>
            <p>Remplissez le formulaire. Aucun compte n’est nécessaire. Votre demande sera transmise au club et restera en attente jusqu’à son examen par les responsables.</p>
            <div className="privacy-note"><strong>Protection des informations</strong><p>Les renseignements fournis servent uniquement au traitement de votre demande d’inscription. Ils ne sont pas affichés sur le site public.</p></div>
            <p className="contact-small">Besoin d’aide ?<br /><strong>65 41 42 42 / 95 41 42 42</strong><br />wadihawaras@gmail.com</p>
          </div>

          <form className="registration-form" onSubmit={submit}>
            <h3>Informations du joueur</h3>
            <div className="form-grid">
              <label>Nom *<input name="last_name" value={form.last_name} onChange={update} required maxLength="80" /></label>
              <label>Prénom(s) *<input name="first_name" value={form.first_name} onChange={update} required maxLength="80" /></label>
              <label>Date de naissance *<input type="date" name="date_of_birth" value={form.date_of_birth} onChange={update} required max={new Date().toISOString().slice(0,10)} /></label>
              <label>Nationalité<input name="nationality" value={form.nationality} onChange={update} required maxLength="80" /></label>
              <label>Ville<input name="city" value={form.city} onChange={update} required maxLength="100" /></label>
              <label>Téléphone du contact *<input name="phone" type="tel" value={form.phone} onChange={update} required maxLength="30" placeholder="Ex. 65 41 42 42" /></label>
              <label>Email (facultatif)<input name="email" type="email" value={form.email} onChange={update} maxLength="254" /></label>
              <label>Catégorie demandée *<select name="requested_category" value={form.requested_category} onChange={update}><option>U12</option><option>U15</option><option>U17</option><option>U18</option><option>Seniors</option><option>À définir</option></select></label>
              <label>Poste préféré<select name="preferred_position" value={form.preferred_position} onChange={update}><option value="">Choisir (facultatif)</option><option>Gardien</option><option>Défenseur</option><option>Milieu</option><option>Attaquant</option><option>Polyvalent</option></select></label>
              <label className="full">Ancien club (facultatif)<input name="previous_club" value={form.previous_club} onChange={update} maxLength="120" /></label>
            </div>

            {isMinor && <div className="guardian-block">
              <h3>Parent ou tuteur légal</h3>
              <p>Le joueur a moins de 18 ans. Les coordonnées et l’autorisation d’un parent ou tuteur sont nécessaires.</p>
              <div className="form-grid">
                <label>Nom complet du parent/tuteur *<input name="guardian_full_name" value={form.guardian_full_name} onChange={update} required maxLength="160" /></label>
                <label>Lien avec le joueur<select name="guardian_relationship" value={form.guardian_relationship} onChange={update}><option value="">Choisir</option><option>Père</option><option>Mère</option><option>Tuteur légal</option><option>Autre responsable légal</option></select></label>
                <label>Téléphone du parent/tuteur *<input name="guardian_phone" type="tel" value={form.guardian_phone} onChange={update} required maxLength="30" /></label>
                <label>Email du parent/tuteur<input name="guardian_email" type="email" value={form.guardian_email} onChange={update} maxLength="254" /></label>
              </div>
              <label className="checkline"><input type="checkbox" name="parental_authorization_confirmed" checked={form.parental_authorization_confirmed} onChange={update} required /> Je confirme être le parent ou le tuteur légal et autoriser cette demande de pré-inscription.</label>
            </div>}

            <label className="checkline consent"><input type="checkbox" name="privacy_consent" checked={form.privacy_consent} onChange={update} required /> J’accepte que les informations ci-dessus soient utilisées par l’AS Wadi Hawar pour étudier cette demande d’inscription. *</label>
            {feedback && <div className={`feedback ${feedback.type}`} role="status">{feedback.text}</div>}
            <button className="button button-primary submit" type="submit" disabled={submitting}>{submitting ? "Envoi en cours…" : "Envoyer ma demande"}</button>
            <small className="required-note">* Champs obligatoires. La pré-inscription ne vaut pas admission définitive.</small>
          </form>
        </section>

        <section className="contact section" id="contact">
          <div><div className="section-kicker">CONTACT</div><h2>Restons en contact.</h2><p>Pour toute information sur le club, les entraînements ou les inscriptions, contactez l’administration de l’AS Wadi Hawar.</p></div>
          <div className="contact-card"><strong>AS WADI HAWAR</strong><span>N’Djaména, Tchad</span><a href="tel:+23565414242">65 41 42 42</a><a href="tel:+23595414242">95 41 42 42</a><a href="mailto:wadihawaras@gmail.com">wadihawaras@gmail.com</a></div>
        </section>
      </main>

      <footer><strong>AS WADI HAWAR</strong><span>Association Sportive de Football · N’Djaména, Tchad</span><small>© {new Date().getFullYear()} AS Wadi Hawar. Tous droits réservés.</small></footer>
    </>
  );
}

export default App;